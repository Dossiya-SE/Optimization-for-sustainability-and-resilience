using JuMP
using HiGHS

# Independent computational verification only.
# It does not replace the manual derivation in the homework.
model = Model(HiGHS.Optimizer)
set_silent(model)

@variable(model, x1 >= 0)
@variable(model, x2 >= 0)

@constraint(model, -x1 + 2x2 <= 16)
@constraint(model,  5x1 + 3x2 <= 50)
@constraint(model,         x2 <= 8)

@objective(model, Max, 2x1 + 5x2)
optimize!(model)

x1v = value(x1)
x2v = value(x2)
zv  = objective_value(model)

@assert isapprox(x1v, 26/5; atol=1e-8)
@assert isapprox(x2v, 8.0;  atol=1e-8)
@assert isapprox(zv, 252/5; atol=1e-8)

println("JuMP/HiGHS verification passed:")
println("  x* = (", x1v, ", ", x2v, ")")
println("  Z* = ", zv)
