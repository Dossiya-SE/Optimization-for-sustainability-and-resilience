# IEE 574 — Homework 2 Julia Visuals

This folder implements the Homework 2 figures for Problems 2–4 using the logic already established in `mainHome.tex`.

## Scientific design rule

The code follows the same order as the written solution:

1. define the mathematical object;
2. verify exact values/relationships;
3. compute only the visible geometric representation;
4. draw the graph-paper coordinate system;
5. add constraints and feasible sets;
6. add derived objects (normal vectors, recession rays, objective contours);
7. emphasize the final mathematical result;
8. export vector PDF/SVG and a high-resolution PNG preview.

The plotting code does **not** use a solver to invent the geometry. Problem 4 has a separate `verify_problem4_jump.jl` file for independent JuMP/HiGHS verification.

## Files

- `src/HW2VisualCore.jl` — common graph-paper theme and half-space clipping engine.
- `problem2_hyperplane.jl` — `H`, `S1`, `S2`, `x0`, normal `a`.
- `problem3_polyhedron.jl` — two-panel `X` + `rec(X)` geometry.
- `problem4_lp_geometry.jl` — feasible polytope, constraints, objective contours, improving direction, optimum.
- `verify_problem4_jump.jl` — independent LP verification.
- `render_all.jl` — renders all three figures.
- `latex_integration.tex` — snippets for replacing the existing TikZ/PGFPlots figures in `mainHome.tex`.

## Install

From this folder:

```bash
julia setup.jl
```

## Render

```bash
julia --project=. render_all.jl
```

Then optionally verify Problem 4 numerically:

```bash
julia --project=. verify_problem4_jump.jl
```

## Outputs

Each script exports:

- PDF — vector master for LaTeX/Canvas submission;
- SVG — editable vector copy;
- PNG — high-resolution visual preview.

The output directory is `figures/`.

## Important limitation of this prepared bundle

The code was written against the current Makie API documented for `Axis`, minor grids, `arrows2d!`, `text!`, and CairoMakie export. Julia is not installed in the current execution environment, so the scripts could not be rendered here. Run `setup.jl` locally first; if your installed Makie version emits an API error, pin/update Makie and adjust only the affected API call rather than changing the mathematics.
