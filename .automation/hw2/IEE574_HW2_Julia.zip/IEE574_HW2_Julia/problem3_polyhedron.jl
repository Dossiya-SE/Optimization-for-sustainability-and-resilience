using CairoMakie
using LaTeXStrings

include(joinpath(@__DIR__, "src", "HW2VisualCore.jl"))
using .HW2VisualCore

# ============================================================
# Problem 3 — Feasible polyhedron and recession geometry
# ============================================================
# X = {x : x₁-2x₂≥-6, x₁-x₂≥-2, x₁≥0, x₂≥1}
# Equivalent ≤ representation used by clipping:
#  -x₁ + 2x₂ ≤ 6
#  -x₁ +  x₂ ≤ 2
#  -x₁        ≤ 0
#        -x₂  ≤ -1

const XLIM = (-0.5, 8.5)
const YLIM = (0.0, 7.5)

constraints_X = [
    (a=(-1.0,  2.0), b= 6.0),
    (a=(-1.0,  1.0), b= 2.0),
    (a=(-1.0,  0.0), b= 0.0),
    (a=( 0.0, -1.0), b=-1.0),
]

# ---------- exact checks from the written derivation ----------
vertices_exact = [(0//1, 1//1), (0//1, 2//1), (2//1, 4//1)]

function feasible_X(p)
    x1, x2 = p
    return (x1 - 2x2 >= -6) &&
           (x1 - x2 >= -2) &&
           (x1 >= 0) &&
           (x2 >= 1)
end

for v in vertices_exact
    @assert feasible_X(v)
end

r1 = (1//1, 0//1)
r2 = (2//1, 1//1)

function recession_direction(d)
    d1, d2 = d
    return (d1 - 2d2 >= 0) &&
           (d1 - d2 >= 0) &&
           (d1 >= 0) &&
           (d2 >= 0)
end

@assert recession_direction(r1)
@assert recession_direction(r2)

visible_X = feasible_polygon(constraints_X, XLIM, YLIM)

fig = Figure(size=(1900, 1080), backgroundcolor=COLORS.white)

Label(
    fig[1, 1:2],
    L"\mathrm{Problem\ 3:}\quad X\ \mathrm{and\ its\ recession\ cone}",
    fontsize=31,
    font=:bold,
    color=COLORS.ink,
    tellwidth=false,
)

# ------------------------------------------------------------
# Panel A — X in x-space
# ------------------------------------------------------------
ax = graphpaper_axis(
    fig[2, 1];
    xlim=XLIM,
    ylim=YLIM,
    xticks=0:1:8,
    yticks=0:1:7,
    title=L"\mathrm{(A)}\quad X\subset\mathbb{R}^2",
)

# Fill is clipped by the viewing window only; no artificial right boundary is stroked.
poly!(ax, as_points(visible_X); color=COLORS.green_fill, strokewidth=0)
draw_coordinate_axes!(ax)

# Draw all four defining boundary lines lightly.
xs = range(0.0, XLIM[2], length=400)
lines!(ax, xs, 0.5 .* xs .+ 3; color=COLORS.ink_soft, linewidth=1.8)
lines!(ax, xs, xs .+ 2;       color=COLORS.ink_soft, linewidth=1.8)
hlines!(ax, [1.0]; color=COLORS.ink_soft, linewidth=1.8)
vlines!(ax, [0.0]; color=COLORS.ink_soft, linewidth=1.8)

# Emphasize only the active boundary of X.
lines!(ax, [0.0, 2.0], [2.0, 4.0]; color=COLORS.ink, linewidth=4.0)
lines!(ax, [2.0, 8.3], [4.0, 0.5*8.3 + 3.0]; color=COLORS.ink, linewidth=4.0)
lines!(ax, [0.0, 8.3], [1.0, 1.0]; color=COLORS.ink, linewidth=4.0)
lines!(ax, [0.0, 0.0], [1.0, 2.0]; color=COLORS.ink, linewidth=4.0)

# Vertices.
vx = Float64[first(v) for v in vertices_exact]
vy = Float64[last(v)  for v in vertices_exact]
scatter!(ax, vx, vy; color=COLORS.gold, markersize=18,
         strokecolor=COLORS.ink, strokewidth=1.1)
text!(ax, -0.08, 0.87; text=L"(0,1)", fontsize=19, align=(:right,:top), color=COLORS.ink)
text!(ax, -0.08, 2.08; text=L"(0,2)", fontsize=19, align=(:right,:bottom), color=COLORS.ink)
text!(ax,  2.12, 4.10; text=L"(2,4)", fontsize=19, align=(:left,:bottom), color=COLORS.ink)

# Extreme recession directions shown on the corresponding unbounded boundary rays.
arrows2d!(ax, [Point2f(5.9, 1.0)], [Vec2f(2.0, 0.0)];
          color=COLORS.red, shaftwidth=4.0, tipwidth=15, tiplength=12)
text!(ax, 6.3, 0.72; text=L"d^{(1)}=(1,0)", fontsize=19, color=COLORS.red,
      align=(:left,:top))

arrows2d!(ax, [Point2f(5.0, 5.5)], [Vec2f(2.4, 1.2)];
          color=COLORS.red, shaftwidth=4.0, tipwidth=15, tiplength=12)
text!(ax, 5.2, 6.15; text=L"d^{(2)}=(2,1)", fontsize=19, color=COLORS.red,
      align=(:left,:bottom))

text!(ax, 3.5, 2.45; text=L"X", fontsize=31, color=COLORS.green,
      align=(:center,:center))

# Constraint labels.
text!(ax, 5.9, 6.12; text=L"x_2=\frac12x_1+3", fontsize=17,
      color=COLORS.ink_soft, rotation=atan(0.5))
text!(ax, 1.15, 3.38; text=L"x_2=x_1+2", fontsize=17,
      color=COLORS.ink_soft, rotation=atan(1.0))

# ------------------------------------------------------------
# Panel B — recession cone in d-space
# ------------------------------------------------------------
DXLIM = (0.0, 4.2)
DYLIM = (0.0, 2.2)

# rec(X) = {d : d₂≥0, d₁≥2d₂}
constraints_rec = [
    (a=( 0.0, -1.0), b=0.0),  # d₂ ≥ 0
    (a=(-1.0,  2.0), b=0.0),  # d₁ ≥ 2d₂
    (a=(-1.0,  0.0), b=0.0),  # d₁ ≥ 0
]
visible_rec = feasible_polygon(constraints_rec, DXLIM, DYLIM)

axr = graphpaper_axis(
    fig[2, 2];
    xlim=DXLIM,
    ylim=DYLIM,
    xticks=0:1:4,
    yticks=0:0.5:2,
    xlabel=L"d_1",
    ylabel=L"d_2",
    title=L"\mathrm{(B)}\quad \operatorname{rec}(X)",
)

poly!(axr, as_points(visible_rec); color=COLORS.blue_fill, strokewidth=0)
draw_coordinate_axes!(axr)

# Cone boundary rays from the origin.
lines!(axr, [0.0, 4.0], [0.0, 0.0]; color=COLORS.ink, linewidth=4.0)
lines!(axr, [0.0, 4.0], [0.0, 2.0]; color=COLORS.ink, linewidth=4.0)

arrows2d!(axr, [Point2f(0.0, 0.0)], [Vec2f(3.25, 0.0)];
          color=COLORS.red, shaftwidth=4.0, tipwidth=15, tiplength=12)
arrows2d!(axr, [Point2f(0.0, 0.0)], [Vec2f(3.2, 1.6)];
          color=COLORS.red, shaftwidth=4.0, tipwidth=15, tiplength=12)

text!(axr, 2.15, 0.13; text=L"d^{(1)}=(1,0)", fontsize=18,
      color=COLORS.red, align=(:center,:bottom))
text!(axr, 2.55, 1.48; text=L"d^{(2)}=(2,1)", fontsize=18,
      color=COLORS.red, align=(:left,:bottom), rotation=atan(0.5))
text!(axr, 2.45, 0.70; text=L"\operatorname{rec}(X)", fontsize=23,
      color=COLORS.blue, align=(:center,:center))

Label(
    fig[3, 1:2],
    L"X\ \mathrm{is\ an\ unbounded\ polyhedron},\qquad " *
    L"\operatorname{rec}(X)=\operatorname{cone}\{(1,0),(2,1)\}",
    fontsize=23,
    color=COLORS.ink_soft,
    tellwidth=false,
)

colgap!(fig.layout, 28)
rowgap!(fig.layout, 16)

stem = joinpath(@__DIR__, "figures", "P3_polyhedron_recession")
export_figure(fig, stem)
println("Saved Problem 3 figure to: ", stem, ".{pdf,svg,png}")
