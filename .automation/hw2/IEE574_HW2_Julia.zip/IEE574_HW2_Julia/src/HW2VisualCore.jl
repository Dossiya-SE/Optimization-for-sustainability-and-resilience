module HW2VisualCore

using CairoMakie
using LaTeXStrings

export COLORS,
       graphpaper_axis,
       draw_coordinate_axes!,
       clip_polygon_le,
       feasible_polygon,
       as_points,
       export_figure

# ------------------------------------------------------------
# Visual system
# ------------------------------------------------------------
# Neutral, print-safe base + restrained accents.
# Geometry must still remain distinguishable in grayscale through
# line type, line weight, and annotations—not color alone.
const COLORS = (
    ink          = RGBf(0.12, 0.13, 0.15),
    ink_soft     = RGBf(0.30, 0.32, 0.35),
    major_grid   = RGBAf(0.12, 0.13, 0.15, 0.16),
    minor_grid   = RGBAf(0.12, 0.13, 0.15, 0.07),
    blue         = RGBf(0.10, 0.30, 0.58),
    blue_fill    = RGBAf(0.10, 0.30, 0.58, 0.12),
    orange       = RGBf(0.76, 0.36, 0.12),
    orange_fill  = RGBAf(0.76, 0.36, 0.12, 0.10),
    green        = RGBf(0.10, 0.45, 0.29),
    green_fill   = RGBAf(0.10, 0.45, 0.29, 0.12),
    gold         = RGBf(0.73, 0.52, 0.10),
    red          = RGBf(0.67, 0.15, 0.16),
    white        = RGBf(1.00, 1.00, 1.00),
)

"""
    graphpaper_axis(parent; xlim, ylim, xticks, yticks, ...)

Create a 2-D Makie `Axis` with a professional graph-paper hierarchy:
minor grid < major grid < coordinate axes < mathematical objects.

`IntervalsBetween(5)` creates five equal sub-intervals between adjacent
major ticks, matching the dense engineering-grid logic used in the homework.
"""
function graphpaper_axis(
    parent;
    xlim::Tuple{<:Real,<:Real},
    ylim::Tuple{<:Real,<:Real},
    xticks,
    yticks,
    xlabel=L"x_1",
    ylabel=L"x_2",
    title="",
    subdivisions::Int=5,
)
    ax = Axis(
        parent;
        xlabel=xlabel,
        ylabel=ylabel,
        title=title,
        aspect=DataAspect(),
        xticks=xticks,
        yticks=yticks,
        xminorticks=IntervalsBetween(subdivisions),
        yminorticks=IntervalsBetween(subdivisions),
        xminorticksvisible=false,
        yminorticksvisible=false,
        xminorgridvisible=true,
        yminorgridvisible=true,
        xminorgridcolor=COLORS.minor_grid,
        yminorgridcolor=COLORS.minor_grid,
        xminorgridwidth=0.65,
        yminorgridwidth=0.65,
        xgridvisible=true,
        ygridvisible=true,
        xgridcolor=COLORS.major_grid,
        ygridcolor=COLORS.major_grid,
        xgridwidth=1.25,
        ygridwidth=1.25,
        spinewidth=1.35,
        bottomspinecolor=COLORS.ink,
        topspinecolor=COLORS.ink,
        leftspinecolor=COLORS.ink,
        rightspinecolor=COLORS.ink,
        xlabelsize=26,
        ylabelsize=26,
        xticklabelsize=17,
        yticklabelsize=17,
        titlesize=27,
        titlegap=14,
        backgroundcolor=COLORS.white,
    )
    xlims!(ax, Float64(xlim[1]), Float64(xlim[2]))
    ylims!(ax, Float64(ylim[1]), Float64(ylim[2]))
    return ax
end

"""Draw the true coordinate axes x₁=0 and x₂=0 above fills but below constraints."""
function draw_coordinate_axes!(ax; linewidth=1.9)
    hlines!(ax, [0.0]; color=COLORS.ink, linewidth=linewidth)
    vlines!(ax, [0.0]; color=COLORS.ink, linewidth=linewidth)
    return ax
end

# ------------------------------------------------------------
# Deterministic half-space clipping
# ------------------------------------------------------------
# We deliberately compute visible feasible polygons from the mathematical
# inequalities instead of hand-entering plotting polygons.

_dot2(a, p) = a[1] * p[1] + a[2] * p[2]

"""
    clip_polygon_le(poly, a, b; atol=1e-10)

Clip a polygon by the closed half-space

    a₁ x₁ + a₂ x₂ ≤ b.

The algorithm is Sutherland-Hodgman clipping. It is used only to obtain the
visible portion inside the chosen plotting window; it does not alter the
underlying mathematical set.
"""
function clip_polygon_le(poly, a, b; atol=1e-10)
    isempty(poly) && return poly

    inside(p) = _dot2(a, p) <= b + atol

    function intersection(s, e)
        dx = e[1] - s[1]
        dy = e[2] - s[2]
        den = a[1] * dx + a[2] * dy
        abs(den) <= atol && error("Degenerate clipping intersection.")
        t = (b - _dot2(a, s)) / den
        return (s[1] + t * dx, s[2] + t * dy)
    end

    out = Tuple{Float64,Float64}[]
    s = poly[end]
    s_in = inside(s)

    for e in poly
        e_in = inside(e)
        if e_in
            if !s_in
                push!(out, intersection(s, e))
            end
            push!(out, (Float64(e[1]), Float64(e[2])))
        elseif s_in
            push!(out, intersection(s, e))
        end
        s = e
        s_in = e_in
    end

    return out
end

"""
    feasible_polygon(constraints, xlim, ylim)

Return the visible polygon formed by intersecting a rectangular viewport with
half-spaces. Each constraint is a named tuple `(a=(a1,a2), b=value)` meaning
`a1*x1 + a2*x2 ≤ b`.
"""
function feasible_polygon(constraints, xlim, ylim)
    xmin, xmax = Float64.(xlim)
    ymin, ymax = Float64.(ylim)

    poly = Tuple{Float64,Float64}[
        (xmin, ymin),
        (xmax, ymin),
        (xmax, ymax),
        (xmin, ymax),
    ]

    for c in constraints
        poly = clip_polygon_le(poly, c.a, c.b)
    end
    return poly
end

as_points(poly) = [Point2f(p[1], p[2]) for p in poly]

"""Export a figure as vector PDF/SVG and a high-resolution PNG preview."""
function export_figure(fig, stem::AbstractString; png_scale=3)
    mkpath(dirname(stem))
    save(stem * ".pdf", fig)
    save(stem * ".svg", fig)
    save(stem * ".png", fig; px_per_unit=png_scale)
    return nothing
end

end # module
