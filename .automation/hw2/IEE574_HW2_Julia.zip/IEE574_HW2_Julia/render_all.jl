include(joinpath(@__DIR__, "problem2_hyperplane.jl"))
include(joinpath(@__DIR__, "problem3_polyhedron.jl"))
include(joinpath(@__DIR__, "problem4_lp_geometry.jl"))
