using Pkg
Pkg.activate(@__DIR__)
Pkg.add(["CairoMakie", "LaTeXStrings", "JuMP", "HiGHS"])
Pkg.precompile()
println("IEE574 HW2 Julia environment is ready.")
