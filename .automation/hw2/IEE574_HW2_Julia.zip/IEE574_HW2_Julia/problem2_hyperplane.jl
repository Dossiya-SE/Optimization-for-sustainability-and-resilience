using CairoMakie
using LaTeXStrings

include(joinpath(@__DIR__, "src", "HW2VisualCore.jl"))
using .HW2VisualCore

# ============================================================
# Problem 2 — Hyperplane and half-spaces
# ============================================================
# Mathematical source:
# H  : 2x₁ + x₂ = 4
# S₁ : 2x₁ + x₂ ≥ 4
# S₂ : 2x₁ + x₂ ≤ 4
# x⁰ = (1,2), a = (2,1)

const XLIM = (-1.0, 3.0)
const YLIM = (-2.0, 6.0)

# ---------- exact mathematical verification ----------
a = (2.0, 1.0)
x0 = (1.0, 2.0)
@assert a[1] * x0[1] + a[2] * x0[2] == 4.0
@assert 2.0 * 0.0 + 4.0 == 4.0   # intercept (0,4)
@assert 2.0 * 2.0 + 0.0 == 4.0   # intercept (2,0)

# Visible half-spaces obtained from the actual inequalities.
# S₁: 2x₁+x₂ ≥ 4  ⇔  -2x₁-x₂ ≤ -4
S1 = feasible_polygon([(a=(-2.0, -1.0), b=-4.0)], XLIM, YLIM)
# S₂: 2x₁+x₂ ≤ 4
S2 = feasible_polygon([(a=( 2.0,  1.0), b= 4.0)], XLIM, YLIM)

fig = Figure(size=(1500, 1150), backgroundcolor=COLORS.white)

Label(
    fig[1, 1],
    L"\mathrm{Problem\ 2:}\quad H,\;S_1,\;S_2\ \mathrm{and\ the\ normal\ vector}",
    fontsize=31,
    font=:bold,
    color=COLORS.ink,
    tellwidth=false,
)

ax = graphpaper_axis(
    fig[2, 1];
    xlim=XLIM,
    ylim=YLIM,
    xticks=-1:1:3,
    yticks=-2:1:6,
    title=L"H:\;2x_1+x_2=4",
)

# 1) Regions first: grid remains visible through transparent fills.
poly!(ax, as_points(S1); color=COLORS.blue_fill, strokewidth=0)
poly!(ax, as_points(S2); color=COLORS.orange_fill, strokewidth=0)

# 2) Coordinate axes.
draw_coordinate_axes!(ax)

# 3) Hyperplane boundary.
xs = range(XLIM[1], XLIM[2], length=300)
lines!(
    ax,
    xs,
    4 .- 2 .* xs;
    color=COLORS.ink,
    linewidth=4.0,
)

# 4) Exact points used in the derivation.
scatter!(ax, [0.0, 2.0], [4.0, 0.0]; color=COLORS.ink, markersize=16)
scatter!(ax, [x0[1]], [x0[2]]; color=COLORS.gold, markersize=19,
         strokecolor=COLORS.ink, strokewidth=1.2)

text!(ax, 0.10, 4.18; text=L"(0,4)", fontsize=20, color=COLORS.ink,
      align=(:left, :bottom))
text!(ax, 2.08, -0.10; text=L"(2,0)", fontsize=20, color=COLORS.ink,
      align=(:left, :top))
text!(ax, 0.93, 1.80; text=L"x^0=(1,2)", fontsize=20, color=COLORS.ink,
      align=(:right, :top))

# 5) Normal vector a=(2,1), anchored at x⁰ exactly as in the written logic.
arrows2d!(
    ax,
    [Point2f(x0...)],
    [Vec2f(a...)];
    color=COLORS.red,
    shaftwidth=4.2,
    tipwidth=16,
    tiplength=13,
)
text!(ax, 2.18, 3.17; text=L"a=(2,1)", fontsize=21, color=COLORS.red,
      align=(:left, :bottom))

# 6) Direct region labels avoid a color-dependent legend.
text!(ax, -0.10, 5.10; text=L"S_1:\;2x_1+x_2\ge4", fontsize=22,
      color=COLORS.blue, align=(:center, :center))
text!(ax, 1.80, -1.10; text=L"S_2:\;2x_1+x_2\le4", fontsize=22,
      color=COLORS.orange, align=(:center, :center))

Label(
    fig[3, 1],
    L"(0,0)\in S_2\qquad a=(2,1)\perp H\qquad x^0=(1,2)\in H",
    fontsize=23,
    color=COLORS.ink_soft,
    tellwidth=false,
)

rowsize!(fig.layout, 2, Relative(1.0))
rowgap!(fig.layout, 16)

stem = joinpath(@__DIR__, "figures", "P2_hyperplane_halfspaces")
export_figure(fig, stem)
println("Saved Problem 2 figure to: ", stem, ".{pdf,svg,png}")
