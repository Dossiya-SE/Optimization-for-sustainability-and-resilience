using CairoMakie
using LaTeXStrings

include(joinpath(@__DIR__, "src", "HW2VisualCore.jl"))
using .HW2VisualCore

# ============================================================
# Problem 4 — LP geometry, objective contours, improving direction
# ============================================================
# max Z = 2x₁ + 5x₂
# s.t. C₁: -x₁ + 2x₂ ≤ 16   (redundant over F)
#      C₂:  5x₁ + 3x₂ ≤ 50
#      C₃:          x₂ ≤ 8
#      x₁,x₂ ≥ 0

const XLIM = (0.0, 11.0)
const YLIM = (0.0, 10.0)

constraints_F = [
    (a=(-1.0,  2.0), b=16.0),
    (a=( 5.0,  3.0), b=50.0),
    (a=( 0.0,  1.0), b= 8.0),
    (a=(-1.0,  0.0), b= 0.0),
    (a=( 0.0, -1.0), b= 0.0),
]

# ---------- exact rational checks from the written solution ----------
vertices = [
    (0//1,   0//1),
    (10//1,  0//1),
    (26//5,  8//1),
    (0//1,   8//1),
]

objective(p) = 2p[1] + 5p[2]
objvals = objective.(vertices)

@assert objvals == [0//1, 20//1, 252//5, 40//1]
@assert findmax(objvals)[2] == 3
@assert vertices[3] == (26//5, 8//1)
@assert objvals[3] == 252//5

# Redundancy certificate for C₁ over the feasible polytope:
# a linear function reaches its maximum at a vertex.
C1_value(p) = -p[1] + 2p[2]
@assert maximum(C1_value.(vertices)) == 16//1

visible_F = feasible_polygon(constraints_F, XLIM, YLIM)

fig = Figure(size=(1680, 1180), backgroundcolor=COLORS.white)

Label(
    fig[1, 1],
    L"\mathrm{Problem\ 4:}\quad \max\;Z=2x_1+5x_2",
    fontsize=31,
    font=:bold,
    color=COLORS.ink,
    tellwidth=false,
)

ax = graphpaper_axis(
    fig[2, 1];
    xlim=XLIM,
    ylim=YLIM,
    xticks=0:1:11,
    yticks=0:1:10,
    title=L"\mathcal{F},\ \mathrm{objective\ contours,\ improving\ direction,\ and}\ x^*",
)

# 1) Feasible set from the constraints—not hand-entered plotting vertices.
poly!(ax, as_points(visible_F); color=COLORS.green_fill, strokewidth=0)
draw_coordinate_axes!(ax)

xs = range(XLIM[1], XLIM[2], length=600)

# 2) Structural constraints.
# C₁ is intentionally dashed because the written solution proves redundancy.
lines!(ax, xs, 8 .+ 0.5 .* xs;
       color=COLORS.orange, linewidth=2.2, linestyle=:dash)
lines!(ax, xs, (50 .- 5 .* xs) ./ 3;
       color=COLORS.ink, linewidth=3.8)
hlines!(ax, [8.0]; color=COLORS.ink, linewidth=3.8)

# Direct constraint labels.
text!(ax, 1.35, 8.95; text=L"C_1:\;-x_1+2x_2=16\ \mathrm{(redundant)}",
      fontsize=17, color=COLORS.orange, rotation=atan(0.5))
text!(ax, 7.40, 4.45; text=L"C_2:\;5x_1+3x_2=50",
      fontsize=18, color=COLORS.ink, rotation=atan(-5/3))
text!(ax, 8.55, 8.17; text=L"C_3:\;x_2=8",
      fontsize=18, color=COLORS.ink)

# 3) Objective contours 2x₁+5x₂=k.
# Draw suboptimal contours lightly and the optimal supporting contour strongly.
for k in (20.0, 40.0)
    ys = (k .- 2 .* xs) ./ 5
    lines!(ax, xs, ys;
           color=COLORS.blue, linewidth=1.9, linestyle=:dot)
end

kstar = 252 / 5
ystar = (kstar .- 2 .* xs) ./ 5
lines!(ax, xs, ystar;
       color=COLORS.blue, linewidth=3.0, linestyle=:dash)

text!(ax, 0.45, 4.18; text=L"Z=20", fontsize=16, color=COLORS.blue,
      rotation=atan(-2/5))
text!(ax, 0.45, 8.17; text=L"Z=40", fontsize=16, color=COLORS.blue,
      rotation=atan(-2/5))
text!(ax, 6.15, 7.72; text=L"Z=Z^*=\frac{252}{5}", fontsize=17,
      color=COLORS.blue, rotation=atan(-2/5))

# 4) Exact extreme points.
vx = Float64[first(v) for v in vertices]
vy = Float64[last(v)  for v in vertices]
scatter!(ax, vx, vy; color=COLORS.gold, markersize=17,
         strokecolor=COLORS.ink, strokewidth=1.1)

text!(ax, 0.15, 0.20; text=L"(0,0)", fontsize=18, color=COLORS.ink,
      align=(:left,:bottom))
text!(ax, 9.85, 0.22; text=L"(10,0)", fontsize=18, color=COLORS.ink,
      align=(:right,:bottom))
text!(ax, 0.16, 8.15; text=L"(0,8)", fontsize=18, color=COLORS.ink,
      align=(:left,:bottom))
text!(ax, 5.42, 8.18; text=L"\left(\frac{26}{5},8\right)", fontsize=19,
      color=COLORS.ink, align=(:left,:bottom))

# 5) Unique optimum.
xstar = (26/5, 8.0)
scatter!(ax, [xstar[1]], [xstar[2]];
         marker=:star5, markersize=31, color=COLORS.red,
         strokecolor=COLORS.ink, strokewidth=1.0)
text!(ax, 5.45, 7.72; text=L"x^*", fontsize=22, color=COLORS.red,
      align=(:left,:top))

# 6) Improving direction c=(2,5), with the exact component ratio.
arrows2d!(
    ax,
    [Point2f(2.30, 1.50)],
    [Vec2f(2.0, 5.0)];
    color=COLORS.red,
    shaftwidth=4.2,
    tipwidth=16,
    tiplength=13,
)
text!(ax, 4.42, 6.62; text=L"c=\nabla Z=(2,5)", fontsize=20,
      color=COLORS.red, align=(:left,:bottom))

# 7) Interior label.
text!(ax, 3.00, 3.05; text=L"\mathcal{F}", fontsize=31,
      color=COLORS.green, align=(:center,:center))

Label(
    fig[3, 1],
    L"x^*=\left(\frac{26}{5},8\right),\qquad " *
    L"Z^*=\frac{252}{5}=50.4,\qquad " *
    L"\mathrm{slope}(Z=k)=-\frac25",
    fontsize=23,
    color=COLORS.ink_soft,
    tellwidth=false,
)

rowgap!(fig.layout, 16)

stem = joinpath(@__DIR__, "figures", "P4_lp_geometry")
export_figure(fig, stem)
println("Saved Problem 4 figure to: ", stem, ".{pdf,svg,png}")
